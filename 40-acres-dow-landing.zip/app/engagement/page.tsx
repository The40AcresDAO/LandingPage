import Link from "next/link"
import { ArrowLeft } from "lucide-react"

export default function Engagement() {
  return (
    <main className="min-h-screen bg-white">
      <div className="container mx-auto px-4 py-8">
        <Link href="/" className="inline-flex items-center text-sm hover:text-gray-600 transition-colors mb-8">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back
        </Link>

        <header className="mb-12 font-mono">
          <div className="text-sm mb-6">
            40 ACRES DAO #004
            <br />
            Cnt: Engagement/Community
          </div>
        </header>

        <article className="max-w-3xl">
          <h1 className="text-4xl font-bold mb-8">ENGAGEMENT</h1>
          <div className="prose prose-gray">
            <p>Community engagement is the heartbeat of 40 ACRES DAO. Our engagement initiatives include:</p>
            <ul>
              <li>Community Events and Meetups</li>
              <li>Online Forums and Discussion Groups</li>
              <li>Collaborative Projects</li>
              <li>Mentorship Programs</li>
            </ul>
            <p>
              Through meaningful engagement, we're building a strong, connected community that supports and uplifts its
              members while driving positive change in the Web3 space.
            </p>
          </div>
        </article>
      </div>
    </main>
  )
}

