import Link from "next/link"
import { ArrowLeft } from "lucide-react"

export default function Education() {
  return (
    <main className="min-h-screen bg-white">
      <div className="container mx-auto px-4 py-8">
        <Link href="/" className="inline-flex items-center text-sm hover:text-gray-600 transition-colors mb-8">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back
        </Link>

        <header className="mb-12 font-mono">
          <div className="text-sm mb-6">
            40 ACRES DAO #002
            <br />
            Cnt: Education/Knowledge
          </div>
        </header>

        <article className="max-w-3xl">
          <h1 className="text-4xl font-bold mb-8">EDUCATION</h1>
          <div className="prose prose-gray">
            <p>Education is at the core of 40 ACRES DAO's mission. We believe in empowering our community through:</p>
            <ul>
              <li>Blockchain Technology Workshops</li>
              <li>Financial Literacy Programs</li>
              <li>Technical Skill Development</li>
              <li>Community-Led Learning Initiatives</li>
            </ul>
            <p>
              Our educational programs are designed to bridge the gap between traditional finance and the emerging world
              of Web3, ensuring our community has the knowledge and tools to succeed in the digital economy.
            </p>
          </div>
        </article>
      </div>
    </main>
  )
}

