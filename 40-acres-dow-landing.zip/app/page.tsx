import NewsTicker from "@/components/news-ticker"
import PolaroidSlideshow from "@/components/polaroid-slideshow"
import ContactForm from "@/components/contact-form"
import Link from "next/link"

export default function Home() {
  return (
    <main className="min-h-screen bg-white">
      <NewsTicker />

      <div className="relative w-full px-4 py-8">
        <div className="absolute right-[10%] top-8">
          <PolaroidSlideshow />
        </div>

        <div className="container mx-auto">
          <header className="font-mono text-center mb-16 mt-8">
            <div className="text-base">
              40 ACRES DAO #001
              <br />
              Cnt: Web3/Community
            </div>
          </header>

          <div className="mt-[500px] w-[90vw] max-w-[1800px] mx-auto">
            <div className="space-y-8">
              <Link href="#education" className="group block hover:text-gray-800 transition-colors">
                <div className="flex items-baseline gap-6 w-full">
                  <span className="text-[4.5rem] md:text-[6rem] font-bold leading-none">1.</span>
                  <span className="text-[4.5rem] md:text-[6rem] leading-none font-bold tracking-tight">EDUCATION</span>
                </div>
              </Link>

              <Link href="#empowerment" className="group block hover:text-gray-800 transition-colors">
                <div className="flex items-baseline gap-6 w-full">
                  <span className="text-[4.5rem] md:text-[6rem] font-bold leading-none">2.</span>
                  <span className="text-[4.5rem] md:text-[6rem] leading-none font-bold tracking-tight">
                    EMPOWERMENT
                  </span>
                </div>
              </Link>

              <Link href="#engagement" className="group block hover:text-gray-800 transition-colors">
                <div className="flex items-baseline gap-6 w-full">
                  <span className="text-[4.5rem] md:text-[6rem] font-bold leading-none">3.</span>
                  <span className="text-[4.5rem] md:text-[6rem] leading-none font-bold tracking-tight">ENGAGEMENT</span>
                </div>
              </Link>
            </div>
          </div>
        </div>

        <section id="education" className="min-h-screen flex items-center py-24">
          <div className="max-w-4xl mx-auto px-4">
            <h2 className="text-6xl font-bold mb-12">EDUCATION</h2>
            <div className="prose prose-lg">
              <p>
                40 ACRES DAO is committed to educating our community about blockchain technology, decentralized finance,
                and digital literacy. Through workshops, seminars, and hands-on training, we empower individuals with
                the knowledge they need to participate in the digital economy.
              </p>
            </div>
          </div>
        </section>

        <section id="empowerment" className="min-h-screen flex items-center py-24">
          <div className="max-w-4xl mx-auto px-4">
            <h2 className="text-6xl font-bold mb-12">EMPOWERMENT</h2>
            <div className="prose prose-lg">
              <p>
                We believe in economic empowerment through technology. Our programs provide resources, tools, and
                opportunities for community members to build wealth and create sustainable futures using blockchain
                technology.
              </p>
            </div>
          </div>
        </section>

        <section id="engagement" className="min-h-screen flex items-center py-24">
          <div className="max-w-4xl mx-auto px-4">
            <h2 className="text-6xl font-bold mb-12">ENGAGEMENT</h2>
            <div className="prose prose-lg">
              <p>
                Community engagement is at the heart of everything we do. Through events, meetups, and collaborative
                projects, we create spaces for meaningful connections and collective growth.
              </p>
            </div>
          </div>
        </section>

        <ContactForm />
      </div>
    </main>
  )
}

