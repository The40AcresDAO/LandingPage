import Link from "next/link"
import { ArrowLeft } from "lucide-react"

export default function Empowerment() {
  return (
    <main className="min-h-screen bg-white">
      <div className="container mx-auto px-4 py-8">
        <Link href="/" className="inline-flex items-center text-sm hover:text-gray-600 transition-colors mb-8">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back
        </Link>

        <header className="mb-12 font-mono">
          <div className="text-sm mb-6">
            40 ACRES DAO #003
            <br />
            Cnt: Empowerment/Growth
          </div>
        </header>

        <article className="max-w-3xl">
          <h1 className="text-4xl font-bold mb-8">EMPOWERMENT</h1>
          <div className="prose prose-gray">
            <p>
              Empowerment through technology and community building is fundamental to our mission at 40 ACRES DAO. We
              focus on:
            </p>
            <ul>
              <li>Community-Driven Initiatives</li>
              <li>Economic Empowerment Programs</li>
              <li>Technology Access and Training</li>
              <li>Leadership Development</li>
            </ul>
            <p>
              Through our empowerment programs, we're creating pathways for community members to take control of their
              financial future and participate actively in the digital economy.
            </p>
          </div>
        </article>
      </div>
    </main>
  )
}

