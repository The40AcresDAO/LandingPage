import Link from "next/link"

export default function NavBar() {
  return (
    <nav className="bg-white shadow-md">
      <div className="container mx-auto px-4 py-4 flex justify-between items-center">
        <Link href="/" className="text-2xl font-bold">
          40 Acres Dow
        </Link>
        <div className="space-x-4">
          <Link href="#education" className="text-gray-600 hover:text-gray-900">
            Education
          </Link>
          <Link href="#empowerment" className="text-gray-600 hover:text-gray-900">
            Empowerment
          </Link>
          <Link href="#engagement" className="text-gray-600 hover:text-gray-900">
            Engagement
          </Link>
        </div>
      </div>
    </nav>
  )
}

