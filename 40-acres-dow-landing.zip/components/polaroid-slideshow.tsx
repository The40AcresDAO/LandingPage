"use client"

import { useState, useEffect } from "react"
import Image from "next/image"

interface SlideImage {
  src: string
  alt: string
}

export default function PolaroidSlideshow() {
  const [currentIndex, setCurrentIndex] = useState(0)

  const images: SlideImage[] = [
    {
      src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-02-11%20at%208.59.50%20AM-CEw4EPlKo6cSAk7yaioSmr55EprMCp.png",
      alt: "40 ACRES DAO community event",
    },
    {
      src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/04970030.JPG-968uSZ8OmYPQwnSSXcnfPPyMWVgzgk.jpeg",
      alt: "Community night gathering",
    },
    {
      src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/_DSC2688.jpg-Im2918b1pHVu533keKyMxRgy8oJEZ6.jpeg",
      alt: "Tech and culture",
    },
    {
      src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/ETH%20CC%20RUSS-zSjfkimdK7tZQDO03OIXzxAEUAhSy9.jpeg",
      alt: "Community discussion",
    },
  ]

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentIndex((current) => (current + 1) % images.length)
    }, 4000)
    return () => clearInterval(timer)
  }, [])

  return (
    <div className="relative w-[340px] h-[425px] transform rotate-2 transition-transform hover:rotate-0 duration-300">
      {images.map((image, index) => (
        <div
          key={image.src}
          className={`absolute inset-0 bg-white p-4 shadow-lg transition-opacity duration-500 ${
            index === currentIndex ? "opacity-100 z-10" : "opacity-0 z-0"
          }`}
        >
          <div className="relative w-full h-[85%] mb-4">
            <Image
              src={image.src || "/placeholder.svg"}
              alt={image.alt}
              fill
              className="object-cover"
              priority={index === 0}
            />
          </div>
          <div className="text-sm text-gray-600 font-mono">40 ACRES DAO #{String(index + 1).padStart(3, "0")}</div>
        </div>
      ))}
    </div>
  )
}

