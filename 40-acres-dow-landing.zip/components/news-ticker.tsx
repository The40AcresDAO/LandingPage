"use client"

export default function NewsTicker() {
  return (
    <div className="bg-red-600 text-white overflow-hidden whitespace-nowrap py-2 relative">
      <div className="animate-ticker inline-block">
        BREAKING NEWS: 40 ACRES DAO - EMPOWERING THROUGH EDUCATION, ENGAGEMENT, AND COMMUNITY
      </div>
      <div className="animate-ticker2 inline-block absolute left-full">
        BREAKING NEWS: 40 ACRES DAO - EMPOWERING THROUGH EDUCATION, ENGAGEMENT, AND COMMUNITY
      </div>
    </div>
  )
}

